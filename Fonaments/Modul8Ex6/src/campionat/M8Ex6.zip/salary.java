package campionat;

public interface salary {

	abstract int setSalary();

}
